import './components/fayozbek/fa.css';
import FaNav from './components/fayozbek/FaNav';
import FaSlider from './components/fayozbek/FaSlider';
import FaCards from './components/fayozbek/FaCards';
import FaProductLink from './components/fayozbek/FaProductLink';
import JaCarousel from './components/javohir/JaCarousel'
import Jatitle from './components/javohir/JaTitle';
import JaSofa from './components/javohir/JaSofa'
// import JaFeatured from './components/javohir/JaFeatured';
import JaFooter from './components/javohir/JaFooter';
import FaGrid from './components/fayozbek/FaGrid';

function App() {
  return (
    <>
      <FaNav />
      <FaSlider />
      <FaCards />
      <FaProductLink />
      <Jatitle title="Responsive" text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis nobis quae, quos sed natus quas fuga magnam deserunt?"/>
      <JaCarousel/>
      <JaSofa/>
      <Jatitle title="Responsive" text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis  nobis quae, quos sed natus quas fuga magnam deserunt?"/>
      {/* <JaFeatured/> */}
      <FaProductLink />
      <FaGrid />
      <JaFooter/>
    </>
  );
}



export default App;
