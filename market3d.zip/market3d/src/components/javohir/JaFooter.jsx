import React from 'react'
import './ja.css'

const JaFooter = () =>{
  return(
    <div className='container-fluid bg-dark p-5'>
      <div className="container">
          <div className="row">
              <div className="col-md-4">
                  <p className='text-light'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius quis expedita modi velit blanditiis, molestias natus ratione ad placeat dolores assumenda distinctio ipsa! Veritatis, id magni labore magnam mollitia maxime.</p>
              </div>
              <div className="col-md-2">
                  <ul className='ja__href'>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                  </ul>
              </div>
              <div className="col-md-2">
                 <ul className='ja__href'>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                      <li><a href="#">salom</a></li>
                  </ul>
              </div>
              <div className="col-md-4">
                  <p className='text-light'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Et natus dolor magnam, totam veniam aliquam sequi
                  </p>
                  <input type="text" className='form-control' placeholder='Pochta' style={{background: 'transparent', opacity: '0.4', color: "white"}} />
              </div>

              <div className="col mt-5">
                  <h1 className='ja__footer_icons'>Salom</h1>
              </div>

              <div className="row text-light text-center my-3">
              <div className="col">
                  <p>Lorem ipsum dolor sit amet.</p>
              </div>
              <div className="col">
              <p>Lorem ipsum dolor sit amet.</p>
              </div>
              </div>
          </div>
      </div>
    </div>
  )
}

export default JaFooter