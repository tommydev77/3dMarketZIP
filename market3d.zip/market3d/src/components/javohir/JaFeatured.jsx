import React from "react";
import "./ja.css";

const JaFeatured = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-6">
            <div className="ja__carousel">
              <img
                src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                width={"90%"}
                alt=""
              />
              <div className="row">
                <div className="col">
                  <small>Salom Hammaga</small>
                  <b>$37.12</b>
                </div>
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="row">
              <div className="col">
                <div className="ja__carousel">
                  <img
                    src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                    width={"90%"}
                    alt=""
                  />
                  <div className="row">
                    <div className="col">
                      <small>Salom Hammaga</small>
                      <b>$37.12</b>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col">
                <div className="ja__carousel">
                  <img
                    src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                    width={"90%"}
                    alt=""
                  />
                  <div className="row">
                    <div className="col">
                      <small>Salom Hammaga</small>
                      <b>$37.12</b>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="row">
              <div className="col">
                <div className="ja__carousel">
                  <img
                    src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                    width={"90%"}
                    alt=""
                  />
                  <div className="row">
                    <div className="col">
                      <small>Salom Hammaga</small>
                      <b>$37.12</b>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col">
                <div className="ja__carousel">
                  <img
                    src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                    width={"90%"}
                    alt=""
                  />
                  <div className="row">
                    <div className="col">
                      <small>Salom Hammaga</small>
                      <b>$37.12</b>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="row">
              <div className="col">
                <div className="ja__carousel">
                  <img
                    src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                    width={"90%"}
                    alt=""
                  />
                  <div className="row">
                    <div className="col">
                      <small>Salom Hammaga</small>
                      <b>$37.12</b>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col">
                <div className="ja__carousel">
                  <img
                    src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                    width={"90%"}
                    alt=""
                  />
                  <div className="row">
                    <div className="col">
                      <small>Salom Hammaga</small>
                      <b>$37.12</b>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-6">
            <div className="ja__carousel">
              <img
                src="https://images.unsplash.com/photo-1613525850352-52de526e2336?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=739&q=80"
                width={"90%"}
                alt=""
              />
              <div className="row">
                <div className="col">
                  <small>Salom Hammaga</small>
                  <b>$37.12</b>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default JaFeatured;
