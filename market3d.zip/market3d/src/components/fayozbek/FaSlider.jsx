import React, { Component } from "react";

class FaSlider extends Component {
  componentDidMount() {
    window.addEventListener("load", () => {
      this.sliderAdaptive();
    });
  }

  sliderAdaptive = () => {
    let pagesSlider = document.querySelector(".fa-slider_pages");
    let container = document.querySelector(".container");
    let sliderIndicator = document.querySelectorAll(".fa-slider .fa-circle");
    pagesSlider.style.width = container.offsetWidth * 3 + "px";
    let containerWidth

        sliderIndicator.forEach(item => {
            containerWidth = container.offsetWidth;
            item.addEventListener('click',function () {
                sliderIndicator.forEach(item => item.classList.remove('active-indicator'));
                if (this.title === 'Page 1') {
                    pagesSlider.style.left = '0';
                    this.classList.add('active-indicator');
                } else if (this.title === 'Page 2') {
                    pagesSlider.style.left = '-' + containerWidth + 'px';
                    this.classList.add('active-indicator');
                } else if (this.title === 'Page 3') {
                    pagesSlider.style.left = '-' + containerWidth * 2 + 'px';
                    this.classList.add('active-indicator');
                }
        })
    })
  };

  render() {
    return (
      <>
        <div className="fa-slider">
          <div className="container">
            <div className="fa-slider_pages">
              <div className="fa-slider_page1">
                <div className="fa-slider_left">
                  <h2>Modern House 3D Model</h2>
                  <p className="fa--grey">
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Beatae cumque. Beatae cumque Beatae cumque
                  </p>
                  <button className="fa--btn">BUY NOW</button>
                </div>
                <div className="fa-slider_right">
                  <img
                    src={require("./fa-images/obj_house.png")}
                    alt="House 3D"
                  />
                </div>
              </div>
              <div className="fa-slider_page1">
                <div className="fa-slider_left">
                  <h2> 3D Model Modern House</h2>
                  <p className="fa--grey">
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Beatae cumque. Beatae cumque Beatae cumque
                  </p>
                  <button className="fa--btn">BUY NOW</button>
                </div>
                <div className="fa-slider_right">
                  <img
                    src={require("./fa-images/obj_house.png")}
                    alt="House 3D"
                  />
                </div>
              </div>
              <div className="fa-slider_page1">
                <div className="fa-slider_left">
                  <h2>Modern 3D Model House </h2>
                  <p className="fa--grey">
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit.
                    Beatae cumque. Beatae cumque Beatae cumque
                  </p>
                  <button className="fa--btn">BUY NOW</button>
                </div>
                <div className="fa-slider_right">
                  <img
                    src={require("./fa-images/obj_house.png")}
                    alt="House 3D"
                  />
                </div>
              </div>
            </div>
            <div className="fa-slider_indicator">
              <i className="far fa-circle active-indicator" title="Page 1" />
              <i className="far fa-circle" title="Page 2" />
              <i className="far fa-circle" title="Page 3" />
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default FaSlider;
