import React, { Component } from "react";

class FaNav extends Component {
    toggleNav = () => {
        document.querySelector('.fa-lists').classList.toggle('fa-listsResponse');
        document.querySelector('.statistika').classList.toggle('fa-listsResponse');
    }

  render() {
    return (
      <>
        <header>
          <div className="container">
            <nav>
              <div className="nav-logo">SHOP</div>
              <ul className="fa-lists">
                <li>
                  <a href="home.html">HOME</a>
                </li>
                <li>
                  <a href="shop.html">SHOP</a>
                </li>
                <li>
                  <a href="categories.html">CATEGORIES</a>
                </li>
                <li>
                  <a href="blog.html">BLOG</a>
                </li>
                <li>
                  <a href="pages.html">PAGES</a>
                </li>

              </ul>
              <div className="statistika">
                <i className="far fa-search" />
                <i className="far fa-heart"> (50) </i>
                <i className="far fa-shopping-cart"> (23) </i>
              </div>
                <i className="fa fa-bars" onClick={() => {this.toggleNav()}}></i>
            </nav>
          </div>
        </header>
      </>
    );
  }
}

export default FaNav;
